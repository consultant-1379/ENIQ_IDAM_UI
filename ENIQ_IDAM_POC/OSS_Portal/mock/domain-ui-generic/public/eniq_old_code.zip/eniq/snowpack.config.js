import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const externalModules = require('./config/config.package.json').modules;

/** @type {import("snowpack").SnowpackUserConfig } */
const CONFIG = {
  workspaceRoot: '/',
  mount: {
    config: '/',
    apps: '/apps',
    components: '/components',
    './node_modules/@eui/theme/dist/fonts': {
      url: '/assets/fonts',
      resolve: true,
      static: true,
    },
    './node_modules/@eui/theme': {
      url: '/libs/shared/@eui/theme',
      static: true,
    },
    './node_modules/@eui/container': {
      url: '/libs/shared/@eui/container',
      static: true,
    },
    //  Navigation menu
    './node_modules/@eui/navigation-menu': {
      url: '/libs/@eui/navigation-menu',
      resolve: true,
      static: false,
    },
  },
  plugins: ['@eui/import-css-plugin'],
  packageOptions: {
    external: [...externalModules.map(module => module.name)],
  },
  devOptions: {},
  buildOptions: {
    metaUrlPath: 'libs',
  },
};

/** @type {import("snowpack").SnowpackUserConfig } */
export default CONFIG;
