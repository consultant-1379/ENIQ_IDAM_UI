/**
 * Component UserProfile is defined as
 * `<e-user-profile>`
 *
 * @extends {LitComponent}
 */
import { LitComponent, html, definition } from '../../../libs/pkg/@eui/lit-component.js';
const style = "* style goes here */:host{  display: block;}.container{    padding: 1em 0;}.padding-sides{  padding: 0 1em;}.page-header{    display: flex;    align-items: center;    justify-content: space-between;}.page-header .home-icon eui-icon{      --icon-color: #878181;      --icon-size: 3em;     margin-right: 0.5em;}.user-profile eui-tabs eui-tab{    font-size: 18px;    margin-right: 10px;    border: 1px solid;    border-bottom: none;    height:33px;}.user-profile eui-tabs eui-tab.first{  margin-left: 0.9em;}.user-profile eui-tabs eui-tab[selected]{   background-color: #1174e6;    color: #fff;}.user-profile eui-tabs eui-tab[selected]:focus{     outline: 1px solid transparent;}.user-profile eui-tabs>div[selected]{    margin-top: -5px;    border-top: 1px solid;} .tab-content {    margin-top: 2.5em;}form div{    margin-bottom: 1em;}form .form-submit{   margin-top: 2.5em;}.user-password,.grid {    display: grid;    grid-template-columns: auto auto auto auto;    grid-column-gap: 2em;    grid-template-columns: 30% 15% auto auto;}.grid .column-1{max-width: 320px;}.grid .column-2{max-width: 200px;}.user-password .user-password-form1{        max-width: 330px;}.user-password-form form div {    display: flex;    justify-content: space-between;    align-items: baseline;}.user-password-content .content1{    max-width: 200px;}.user-password-content .content h3,.grid .content h3{   font-size: 1.5rem;    margin-top: 10px;    margin-bottom: 10px;}/*password-less setup*/.passwordless-setup .setup-button{    display: flex;    flex-flow: column;    gap: 2em;}.passwordless-setup .message eui-textarea{    box-sizing:border-box;    background: var(--input-background, #fff);    border: 1px solid var(--input-border, #878787);    padding: 5px 7px 4px;}.passwordless-setup .message eui-textarea:focus{    --purple:transparent;}.btn-radius-pill{  --btn-radius:10px;}.private-key .key-button{  margin: auto 0;  text-align: center;}";;
import { Tabs } from '../../../libs/pkg/@eui/layout/tabs.js';
import { Tab } from '../../../libs/pkg/@eui/layout/tab.js';
import { Tile } from '../../../libs/pkg/@eui/layout/tile.js';
import { TextField } from '../../../libs/pkg/@eui/base/text-field.js';
import { Button } from '../../../libs/pkg/@eui/base/button.js';
import { Icon } from '../../../libs/pkg/@eui/theme/icon.js';
import { Textarea } from '../../../libs/pkg/@eui/base/text-area.js';

export default class UserProfile extends LitComponent {
 //  Uncomment this block to add initialization code
 //  constructor() {
 //    super();
     // initialize       
 //  }

  static get components() {
    return {
      // register components here
         'eui-tabs':Tabs,
         'eui-tab':Tab, 
         'eui-tile': Tile,
         'eui-text-field': TextField,
         'eui-button': Button,
         'eui-icon':Icon,
         'eui-textarea':Textarea,
    };
  }

didRender(){
      this.bubble('app:title', { displayName: 'Profile' });    
    //console.log('in didconnect');
    setTimeout(()=>this._shadowdomstyle(),1000)

}
//getting password fields

_shadowdomstyle =()=>{
        let component = document.querySelector("eui-container").shadowRoot.querySelector("e-user-profile");
	let passwrd_fields = component.shadowRoot.querySelectorAll("#password-upate> div > eui-text-field");

      // console.log(passwrd_fields.length);
         console.log(passwrd_fields);
     if(passwrd_fields != null && passwrd_fields.length > 0 ){
	     for( let field of passwrd_fields){
		   field.shadowRoot.querySelector("input").setAttribute('style', '-webkit-text-security: disc!important;');
		 }
	  }

}
//password validator
validate =(password)=>{
    let minMaxLength = /^[\s\S]{8,}$/;
    let upper = /[A-Z]/; 
    let lower = /[a-z]/;
    let number = /[0-9]/;
    let special = /[@!$#%?]/;
    let notPermitted =/[ "&'()*+,\-./:;<=>[\\\]^_`{|}~]/;
    let count = 0;
   //console.log(password);

   if (minMaxLength.test(password) && !notPermitted.test(password) ){
        // Only need 3 out of 4 of these to match
        if (upper.test(password)) count++;
        if (lower.test(password)) count++;
        if (number.test(password)) count++;
        if (special.test(password)) count++;
    }
      console.log(count);
     //return count >= 3;
     return count == 4 ;
}
//form button disable and enable
disablebutton=(buttonPath,value)=>{
       if(value == 'enabled'){
	   if(buttonPath.hasAttribute('disabled')){
		buttonPath.removeAttribute('disabled');
	    }
	}
    if(value == 'disabled'){
	   buttonPath.setAttribute("disabled", "");
    }
}
//password validation
passwwordValidator =(event) =>{
    //calling and storing vale from  validate function
    const validateValue =this.validate(event.detail.value);
    const submitButtonPath = event.target.parentNode.parentNode.querySelector("div.form-submit > eui-button");
    const elementPath = event.target.shadowRoot.querySelector("div > div.input__prefix__suffix"); 
     console.log(this.validate(event.detail.value));
     console.log(event.target.tagName);
    if(validateValue === false){
      this.disablebutton(submitButtonPath,"disabled")
      //  event.target.setCustomValidity('Please enter the requested format.');
      //  elementPath.classList.add("invalid");
     }
    if(validateValue === true){
       //if(elementPath.classList.contains('invalid')){
       //    event.target.setCustomValidity('');
       //    elementPath.classList.remove("invalid");
       //  }

        this.disablebutton(submitButtonPath,"enabled")
     }
}
//check New and Re-enter password
passwordVerify=(event)=>{
  const reEnterPassword = event.detail.value;
  const newpassword = event.target.parentNode.parentNode.querySelector("div.new-password > eui-text-field").value;
  const submitButtonPath = event.target.parentNode.parentNode.querySelector("div.form-submit > eui-button");
  if((reEnterPassword != '') &&  (newpassword != '')){
      if(reEnterPassword == newpassword){
          console.log('Re-enter and new password same');
          this.disablebutton(submitButtonPath,"enabled");
          event.target.setCustomValidity('');
          this.passwwordValidator(event);          
        }
      if(reEnterPassword != newpassword){
          console.log('Re-enter and new password not same');
          this.disablebutton(submitButtonPath,"disabled");
          event.target.setCustomValidity('New and Re-enter password should be same.');
        }

   }

}

  /**
   * Render the <e-user-profile> component. This function is called each time a
   * prop changes.
   */
  render() {
   
   // return html`<h1>Your component markup goes here</h1>
     return html `<div class="container"> 
         <div class="page-header padding-sides">
             <div class="page-title"><h1>ENIQ User Self Service</h1></div>
             <div class="home-icon">
		<eui-link href="#todo-app/app-launcher">
		   <eui-icon name="home"></eui-icon>
		</eui-link>
	    </div>
         </div>
       <div class="user-profile">
       <! ––User Self Service  Tabs ––>
        <eui-tabs>
          <eui-tab class="first" selected>
           <label>Profile Update</label>
          </eui-tab>
          <eui-tab>
           <label>Password Update</label>
          </eui-tab>
          <eui-tab>
             <label>Setup Passwordless [RHEL]</label>
          </eui-tab>
          <! ––  Tabs content ––>
           <! –– profile-update  Tab content ––>
         <div slot="content" class="padding-sides" selected>
           <div class=" userprofile tab-content grid">	
              <div class="userprofile-form column-1">
                <form id="profile-update">		
		   <div class="first-name">
		      <eui-text-field name="first-name" placeholder="First Name" pattern="^[A-Za-z]+$"></eui-text-field>
		   </div>
                   <div class="last-name">
		      <eui-text-field name="last-name" placeholder="Last Name" pattern="^[A-Za-z]+$"></eui-text-field>
		   </div>			
		   <div class="email">
		       <eui-text-field name="email" placeholder="Email" pattern="^[\w.+\-]+@ericsson\.com$"></eui-text-field>
		   </div>
		   <div class="form-submit">
		       <eui-button class="btn-radius-pill">Update</eui-button>
		    </div>
	       </form>
             </div>			
	   </div>
         </div>
         <! ––password-upate  Tab content ––>
        <div slot="content" class="padding-sides">
           <div class="user-password tab-content grid">
              <div class=" user-password-form column-1">	
                  <form id="password-upate">		
		      <div class="old-password">
			  <label>Enter Old password</label>
		          <eui-text-field   name="old-password"  minlength="8" class="oldpassword"
                           pattern="(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@!$#%?])[0-9A-Za-z@!$#%?]{8,16}$" 
                           maxlength="16" placeholder="Old password"
                           @change="${(event) =>this.passwwordValidator(event)}">
                          </eui-text-field>
		       </div>
                       <div class="new-password">
			  <label>Enter New password</label>
			  <eui-text-field name="new-password" class="newpassword"
                            pattern="(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@!$#%?])[0-9A-Za-z@!$#%?]{8,16}$" 
			    minlength="8" maxlength="16" placeholder="New password"
                            @change="${(event) =>this.passwwordValidator(event)}">
                          </eui-text-field>
			</div>			
			<div class="re-enter-password">
			  <label>RE-Enter New password</label>
			  <eui-text-field name="re-enter-password" class="reenterpassword"
                            pattern="(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@!$#%?])[0-9A-Za-z@!$#%?]{8,16}$" 
			    minlength="8" maxlength="16" placeholder="Re-Enter password"
                            @change="${(event) =>this.passwordVerify(event)}">
                          </eui-text-field>
			</div>
			<div class="form-submit">
			  <eui-button class="btn-radius-pill">Update</eui-button>
		        </div>
		 </form>			
             </div>
	    <div class="user-password-content content column-2">
	        
	           <h3>Password Guidelines</h3>
                  <p>Password shall be 8-16 characters long,
                     should have atleast one number, one special character[!@#$%&*]</p>
	         	   
	   </div>
        </div>	
	
        </div>
      <! ––Setup Passwordless   Tab content ––>
       <div slot="content" class="padding-sides">
   	  <!--passwordLess setup  -->
		 <div class='passwordless-setup grid tab-content'>
			<div class="setup-button column-1">
			  <eui-button class="btn-radius-pill" fullwidth>
				Click here to start password-less setup
			  </eui-button>
			  <div class="message">
                            <eui-textarea name="status-message" cols="20" rows="3" readonly
			      placeholder="[execution status message i.e.success/failure to be displayed here]"  fullwidth>
			    </eui-textarea>
                          </div>
			</div>
			<div class='setup-content content column-2'>
			 <h3 class="tab-title">Note</h3>
			 <p>Passwordless setup is available only for ENIQ-S RHEL server access. 
			    The user should be preexisting in RHEL before initiating this password-less setup.</p>
			</div>
		 </div>
		 <!--private key -->
		 <div class='private-key grid'>
		    <div class="key-button column-1">
			   <eui-button class="btn-radius-pill" href="./user-profile.css" download="private-key" fullwidth>
                              Download Private key
                           </eui-button>
			</div>
			<div class="key-content content column-2">
				<h3 class="tab-title">Warning</h3>
				<p>The private key must be kept in a secure location and shall never be shared with anyone else.</p>
			</div>
 		 </div>
       </div>
       <! ––End Setup Passwordless Tab content  ––>
      </eui-tabs>
     </div>
</div>`;
  }
}

/**
 * @property {Boolean} propOne - show active/inactive state.
 * @property {String} propTwo - shows the "Hello World" string.
 */
definition('e-user-profile', {
  style,
  props: {
    propOne: { attribute: true, type: Boolean },
    propTwo: { attribute: true, type: String, default: 'Hello World' },
  },
})(UserProfile);
