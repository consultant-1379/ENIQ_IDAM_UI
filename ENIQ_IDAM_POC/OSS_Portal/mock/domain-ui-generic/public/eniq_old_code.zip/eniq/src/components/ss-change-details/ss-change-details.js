/**
 * Component SsChangeDetails is defined as
 * `<e-ss-change-details>`
 *
 * @extends {LitComponent}
 */
import { LitComponent, html, definition } from '../../../libs/pkg/@eui/lit-component.js';
const style = "/* style goes here */:host{  display: block;} .container {  padding: 1.6em 1em;}.container .content-block {  display: flex;  /* gap: 14px; */  margin-top: 1em;}.content-block .column-1, .content-block .column-2 {  flex-basis: 50%;   margin-bottom: 1.4em; }.container .block-title {  font-size: 16px;  padding-bottom: 0.2em;  margin-bottom: var(--space-large);  max-width: 100%;}.container .block-title::after{  content: '';  height: 3px;  width: 50%;  border-bottom: 1px solid #c8c8c8;  display: block;}/* text fields */.content-block .column-1 .form-fields {  display: flex;  /* align-items: center; */  gap: 1em;  margin-bottom: var(--space-large,16px);}.content-block .column-1 .form-fields label {  flex-basis: 140px;}/* Buttons */.buttons .content-block .column-1 .form-fields{  display: flex;  gap: 1em;  justify-content: right;  padding-right: 1%;}/* media quries */@media only screen and (max-width: 768px) {  .container .content-block{     flex-direction: column;    margin-bottom: 1em;   }   .content-block .column-1,   .content-block .column-2{      flex-basis: 100%;      width: 100%;   }   .policies{border: none;}}";;
import { Button,TextField } from '../../../libs/pkg/@eui/base.js';

export default class SsChangeDetails extends LitComponent {
  // Uncomment this block to add initialization code
  constructor() {
    super();
    // initialize
    this.userData={ username: 'ClOGNEci', firstname: 'Joe', lastname: 'Bloggs', 
    email: 'j.bloggs@yahoo.com', app: 'NetAn', groups: 'NetAn ReadOnly', status: 'Disabled' }
  }

  static get components() {
    return {
      // register components here
      'eui-button':Button,
      'eui-text-field':TextField
    };
  }
//didConnect
didConnect(){
  this.bubble('app:lineage', { metaData: this.metaData });
  this.bubble('app:subtitle', {subtitle: this.metaData?.descriptionShort,});

}
//didRender
didRender(){
  //form text fields
  this.firstname = this.shadowRoot.querySelector("#firstname");
  this.lastname = this.shadowRoot.querySelector("#lastname");
  this.email = this.shadowRoot.querySelector("#email");
  //add user data to form
  setTimeout(() => {
    this.firstname.value = this.userData.firstname;
    this.lastname.value=this.userData.lastname;
    this.email.value=this.userData.email;
  }, 400);
}
//check required fields not null
fields_notNull(){
  //check username is null
  let count=0
  if(this.firstname.value.value == ''){
    console.log("firstname is null");
  }else{count++}
  if(this.lastname.value == ''){
    console.log("lastname is null");
  }else{count++}
  if(this.email.value == ''){
    console.log("email is null");
  }else{count++}

  if(count== 3){
     return true
  }else{
    return false
  }
}
//save user data
save_user(){
  console.log("user data saved");
  if(this.fields_notNull()){    
    let user_personalinfo={};
    user_personalinfo.firstname = this.firstname.value;
    user_personalinfo.lastname = this.lastname.value;
    user_personalinfo.email = this.email.value;
    console.log(user_personalinfo);
  }

}
//form cancel()
form_cancel(){
  console.log("form cancel");
}
// component Event handling
handleEvent(event){
  //save user data
  if(event.type ==="click" && event.target.id ==="save"){
    
    this.save_user();
  }
  if(event.type ==="click" && event.target.id ==="cancel"){
    
    this.form_cancel()
  }
  //event handler end
}
  /**
   * Render the <e-ss-change-details> component. This function is called each time a
   * prop changes.
   */
  render() {
    return html`
    <div id="change-details" class="container">
      <!--personal information section-->
      <section class="personal-info">
        <div class="block-title">Personal information</div>
        <div class="content-block">
           <div class="fields column-1">
              <!--First name-->
              <div class="form-fields">
                <label for="first_name">First name</label>
                <eui-text-field name="first_name" placeholder="First name" id="firstname"
                pattern="^[A-Za-z]+$"></eui-text-field>
              </div>

              <!--Last name-->
              <div class="form-fields">
                <label for="last_name">Last name</label>
                <eui-text-field name="last_name" placeholder="Last name" id="lastname"
                pattern="^[A-Za-z]+$"></eui-text-field>
              </div>

              <!--E-mail-->
              <div class="form-fields">
                <label for="email">E-mail</label>
                <eui-text-field name="email" placeholder="Email" id="email"
                pattern="^\\w+([\\.\\-]?\\w+)*@\\w+([\\.\\-]?\\w+)*(\\.\\w{2,3})+$">
                </eui-text-field>
              </div>
           <!-- -->
           </div>           
        </div>
      </section>

      <!--buttons section-->
        <section class="buttons">
          <div class="content-block">
              <div class="fields column-1">
                    <div class="form-fields">
                        <eui-button id="cancel" @click="${this}">Cancel</eui-button>                      
                        <eui-button id="save" primary @click="${this}">Save</eui-button>
                    </div>
              </div>
          </div>
        </section>

    </div>
      
`;}
}

/**
 * @property {Boolean} propOne - show active/inactive state.
 * @property {String} propTwo - shows the "Hello World" string.
 */
definition('e-ss-change-details', {
  style,
  props: {
    propOne: { attribute: true, type: Boolean },
    propTwo: { attribute: true, type: String, default: 'Hello World' },
  },
})(SsChangeDetails);
