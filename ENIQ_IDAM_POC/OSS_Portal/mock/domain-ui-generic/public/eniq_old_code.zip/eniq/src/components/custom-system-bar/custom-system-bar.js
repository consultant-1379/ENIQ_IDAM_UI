/**
 * Component CustomSystemBar is defined as
 * `<e-custom-system-bar>`
 *
 * @extends {LitComponent}
 */
import { LitComponent, html, definition } from '../../../libs/pkg/@eui/lit-component.js';
const style = "/* style goes here */:host {  display: block;  cursor: pointer;  opacity: 0.8;}:host(:hover) {  opacity: 1.0;}";;
import { Tooltip } from '../../../libs/pkg/@eui/base/tooltip.js';
import { Icon } from '../../../libs/pkg/@eui/theme/icon.js';

export default class CustomSystemBar extends LitComponent {
  // Uncomment this block to add initialization code
  // constructor() {
  //   super();
  //   // initialize
  // }

  static get components() {
    return {
      // register components here
      'eui-tooltip': Tooltip,
      'eui-icon':Icon
    };
  }

  /**
   * Render the <e-custom-system-bar> component. This function is called each time a
   * prop changes.
   */
  render() {
    return html`
    <div>
      <eui-tooltip message="App-launcher" position="bottom-end" delay="500" action>
      <eui-icon name="app-launcher"></eui-icon>
      </eui-tooltip>
    </div>
      `;
  }
}

/**
 * @property {Boolean} propOne - show active/inactive state.
 * @property {String} propTwo - shows the "Hello World" string.
 */
definition('e-custom-system-bar', {
  style,
  props: {
    propOne: { attribute: true, type: Boolean },
    propTwo: { attribute: true, type: String, default: 'Hello World' },
  },
})(CustomSystemBar);
