/**
 * Component AppLauncher is defined as
 * `<e-app-launcher>`
 *
 * @extends {LitComponent}
 */
import { LitComponent, html, definition } from '../../../libs/pkg/@eui/lit-component.js';
const style = "/* style goes here */:host{  display: block;}.launcher-bar,.bar-right,.bar-left{    display: flex;    align-items: center;}.launcher-bar{    justify-content: space-between;    background-color: #f5f5f5c4;    margin-bottom: 1em;}.bar-left eui-icon{    --icon-color: #175ba9;    --icon-size: 22px;    padding: 0.5em;}.bar-left .title-left{    font-size: 2em;    font-weight: bold;    padding-right: 2.5em;    padding-left: 0.2em;}.bar-left .title-middle{      font-size: 1.8em;    font-weight: 500;    padding-left: 1.4em;    padding-right: 0.5em;}.bar-right .host,.bar-right .local-time,.bar-right .help,.bar-right .admin{    display: flex;    align-items: center;    padding: 0.2em 0.5em;    border-left: 1px solid #cbcaca;}.bar-right > div >eui-icon{     --icon-size: 18px;} .bar-right .host span,.bar-right .local-time span.time{    font-size: var(--btn-font-size, 14px);    padding: 5px 12px ;    line-height: var(--btn-line-height, 21px);}.bar-right .host span{\tmargin-top: 0.1em;}.bar-right .local-time .time span{  font-size: .8em;}.bar-right .help eui-dropdown,.bar-right .admin eui-dropdown{   --btn-secondary-border:transparent;} /* app launcher-body */.hr-bar{   border-top: 3px solid var(--gray-60);    margin: 0.2em .5em;}.launcher-body{     padding-left: 1em;    padding-right: 1em;    border-left: 3px solid var(--red-46);    margin: 0 0.5em;}.launcher-body .applist .title{      margin-top: 1em;     display: inline-block;}.launcher-body .applist .title eui-icon{  --icon-size: 18px;}.launcher-body .applist .title span{ font-size: 1.5em;}.launcher-body .applist .list{    display: grid;    grid-template-columns: auto auto auto;    gap: 0.5em;    padding: 0.5em 1em;}.launcher-body .applist .list .list-item{   padding-top: 1em;}.launcher-body .applist .list .list-item eui-icon{  --icon-color: Var(--gray-68);}";;
import { Dropdown } from '../../../libs/pkg/@eui/base/dropdown.js';
import { Icon } from '../../../libs/pkg/@eui/theme/icon.js';
import { Link } from '../../../libs/pkg/@eui/base/link.js';

export default class AppLauncher extends LitComponent {
  // Uncomment this block to add initialization code
   constructor() {
     super();
     // initialize
    this.timerInterval = '';
    this.component_path='';
    this.login_user="";
   }

  static get components() {
    return {
      // register components here
        'eui-dropdown': Dropdown,
        'eui-icon':Icon,
        'eui-link':Link,
    };
  }

didConnect(){
 //page title
  this.bubble('app:title', { displayName: 'Application Launcher' }); 
  this.timerInterval = setInterval(this.timerFunction, 1000);
  console.log('didConnect');
  this.logged_user(); 
}

//did Render
didRender(){
  this.component_path= document.querySelector("eui-container").shadowRoot.querySelector("e-app-launcher");
  console.log(this.accesstype);
 // console.log(localStorage.getItem('myCat'));
}

didDisconnect(){
  clearInterval(this.timerInterval);
  console.log('didDisconnect');
}

//get logged user from localstorage
logged_user =()=>{
  this.login_user = JSON.parse((localStorage.getItem("logged_users")));
  console.log(this.login_user);
  if(this.login_user == null){
    window.EUI.Router.goto('todo-app/');
  }
}

//timer function
timerFunction=()=>{
    let timeElement = this.component_path.shadowRoot.querySelector("div.bar-right > div.local-time > span.time");
    
    var datetime = new Date();
    let dateString = datetime.toString();
    let time = dateString.slice(16,21);
    let timeZone = dateString.match(/GMT\+[0-9]+/)[0];
    if(timeElement != null){
         timeElement.innerHTML=time+"<span>("+timeZone+")</span>";
        // console.log(time+' '+timeZone);
     }
}

 //Based on access_type routing to user & Access managment path 
admin_path = () =>{
  if(this.login_user != null){
      if(this.login_user.access == "Admin"){
          window.EUI.Router.goto('todo-app/user-management');  
       }
      if(this.login_user.access == "Eniq_Admin"){
          window.EUI.Router.goto('todo-app/useraccess-management');
      }
  }
}
//user logout
logout = ()=>{
  localStorage.removeItem('logged_users');
   window.EUI.Router.goto('todo-app/');
}
  /**
   * Render the <e-app-launcher> component. This function is called each time a
   * prop changes.
   */
  render() {
    //return html`<h1>Your component markup goes here</h1>`;
      return html`<div class="app-launcher">
      <! –– app-launcher-bar ––>
      <div class='launcher-bar'>
        <div class="bar-left"> 
		<eui-icon name="econ"></eui-icon>
         	<div class="title-left">Ericsson Network IQ</div>
        	 <div class="title-middle">Application Launcher</div>
        </div>
         <div class="bar-right">
            <div class="host">
	  	<eui-icon name="server"></eui-icon>
	  	<span>Host</span>
	    </div>
	    <div class="local-time">
       		<eui-icon name="time"></eui-icon>
               <span class='time'>10.25 <span>(GMT+1)</span></span>
	    </div>
	    <div class="help">
	  	<eui-icon name="help"></eui-icon>
	  	<eui-dropdown class="help-dropdown" data-type="click" label="Help">
			<eui-menu-item value="help-1" label="Help one" ></eui-menu-item>
			<eui-menu-item value="help-2" label="Help Two" ></eui-menu-item>
       		</eui-dropdown>
	   </div>
	   <div class="admin">
	    	<eui-icon name="avatar"></eui-icon>
	    	<eui-dropdown data-type="click" label="Administrator">
			<eui-menu-item value="profile" label="Profile" 
                          @eui-menuItem:click="${() =>window.EUI.Router.goto('todo-app/profile')}">
                        </eui-menu-item>
			<eui-menu-item value="user-access" label="User & Access management" 
			@eui-menuItem:click="${() =>this.admin_path()}">
			</eui-menu-item>
			<eui-menu-item value="logout" label="Logout" 
			@eui-menuItem:click="${() =>this.logout()}">
			</eui-menu-item>
       		 </eui-dropdown>
	  </div>
	
      </div>
  </div>
  <! –– app-launcher-bar end ––>
  <! –– app-launcher-body ––>
  <div class="hr-bar"></div>
  <div class="launcher-body">
  <! –– app-list ––>
  <div class="applist">
    <div class="title">
         <eui-icon name="app-launcher"></eui-icon>
         <span>Application</span>
    </div>
    <div class="list">
		<div class="list-item">
		   <eui-icon name="favorite-solid"></eui-icon>
		   <eui-link href="https://www.ericsson.com/en"" target="_blank">ENQI Application</eui-link>
		</div>
		<div class="list-item">
		   <eui-icon name="favorite-solid"></eui-icon>
		   <eui-link href="https://www.ericsson.com/en" target="_blank">Remote Desktop</eui-link>
		</div>
		<div class="list-item">
		   <eui-icon name="favorite-solid"></eui-icon>
		   <eui-link href="https://www.ericsson.com/en" target="_blank">Network Application</eui-link>
		</div>
		
		<div class="list-item">
		   <eui-icon name="favorite-solid"></eui-icon>
		   <eui-link href="https://www.ericsson.com/en" target="">Information Application</eui-link>
		</div>
		
		<div class="list-item">
		   <eui-icon name="favorite-solid"></eui-icon>
		   <eui-link href="https://www.ericsson.com/en" target="">Network Analysis</eui-link>
		</div>
		
		<div class="list-item">
		   <eui-icon name="favorite-solid"></eui-icon>
		   <eui-link href="https://www.ericsson.com/en" target="">ENQI Servers</eui-link>
		</div>
  	</div>
  </div>
 <! –– app-list end ––>
</div>

  <! –– app-launcher-body ––>
 <! –– component  end ––>
 </div>`;
  }
}

/**
 * @property {Boolean} propOne - show active/inactive state.
 * @property {String} propTwo - shows the "Hello World" string.
 */
definition('e-app-launcher', {
  style,
  props: {
    propOne: { attribute: true, type: Boolean },
    propTwo: { attribute: true, type: String, default: 'Hello World' },
    accesstype:{attribute: true,type:String},
  },
})(AppLauncher);
